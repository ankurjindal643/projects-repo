package com.cg.lms.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.lms.dto.Book;
import com.cg.lms.exception.BookException;
import com.cg.lms.service.BookService;
  
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class BookController {
 
  Logger logger = LoggerFactory.getLogger(BookController.class);	
	
  @Autowired
  BookService bookService;
 
  @GetMapping("/books")
  public ResponseEntity<List<Book>> getAllBooks() {
    try {
    	List<Book> books = bookService.getAllBooks();
    	if (books.isEmpty()) {
    		logger.info("Book Controller : Books List is Empty");
    		return new ResponseEntity<List<Book>>(HttpStatus.NO_CONTENT);
    	}
    	logger.info("Book Controller : " + books);
    	return new ResponseEntity<List<Book>>(books, HttpStatus.OK);
    } catch (BookException e) {
    	logger.error("Book Controller : " + e.getMessage());
    	return new ResponseEntity<List<Book>>(HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }
  
  @GetMapping("/books/{id}")
  public ResponseEntity<Book> getBookById(@PathVariable("id") long id) {
    Book book = bookService.getBookById(id);
 
    if (book!=null) {
      logger.info("Book Controller : " + book);
      return new ResponseEntity<>(book, HttpStatus.OK);
    } else {
      logger.info("Book Controller : Book Not Found");
      return new ResponseEntity<Book>(HttpStatus.NOT_FOUND);
    }
  }
 
  @PostMapping(value = "/books")
  public ResponseEntity<Book> addBook(@RequestBody Book book) {
    try {
    	book.setBookId(1);
      Book _book = bookService.addBook(book);
      logger.info("Book Controller : " + _book);
      return new ResponseEntity<>(_book, HttpStatus.CREATED);
    } catch (BookException e) {
    	logger.error("Book Controller : " + e.getMessage());
    	e.printStackTrace();
      return new ResponseEntity<Book>(HttpStatus.EXPECTATION_FAILED);
    }
  }
 
  @DeleteMapping("/books/{id}")
  public ResponseEntity<HttpStatus> deleteBook(@PathVariable("id") long id) {
    try {
      bookService.deleteBook(id);
      logger.info("Book Controller : Book Deleted Successfully");
      return new ResponseEntity<HttpStatus>(HttpStatus.NO_CONTENT);
    } catch (BookException e) {
      logger.error("Book Controller : " + e.getMessage());
      return new ResponseEntity<HttpStatus>(HttpStatus.EXPECTATION_FAILED);
    }
  }
 
  @DeleteMapping("/books")
  public ResponseEntity<HttpStatus> deleteAllBooks() {
    try {
      bookService.deleteAllBooks();
      logger.info("Book Controller : All Books Deleted Successfully");
      return new ResponseEntity<HttpStatus>(HttpStatus.NO_CONTENT);
    } catch (BookException e) {
      logger.error("Book Controller : " + e.getMessage());
      return new ResponseEntity<HttpStatus>(HttpStatus.EXPECTATION_FAILED);
    }
 
  }
 
  @GetMapping(value = "books/author/{author}")
  public ResponseEntity<List<Book>> findByAuthor(@PathVariable String author) {
    try {
      List<Book> books = bookService.getAllBooksByAuthor(author);
 
      if (books.isEmpty()) {
          logger.info("Book Controller : Books Not Found");
    	  return new ResponseEntity<List<Book>>(HttpStatus.NO_CONTENT);
      }
      logger.info("Book Controller : " + books);
      return new ResponseEntity<>(books, HttpStatus.OK);
    } catch (BookException e) {
    	logger.error("Book Controller : " + e.getMessage());
    	return new ResponseEntity<List<Book>>(HttpStatus.EXPECTATION_FAILED);
    }
  }
 
  @PutMapping("/books/{id}")
  public ResponseEntity<Book> updateBook(@PathVariable("id") long id, @RequestBody Book book) {
    try {
	  
	  Book _book = bookService.updateBook(id, book);
    
    if (_book!=null) {
      logger.info("Book Controller : " + _book);
      return new ResponseEntity<>(_book, HttpStatus.OK);
    } else {
      logger.info("Book Controller : Book Not Found");
      return new ResponseEntity<Book>(HttpStatus.NOT_FOUND);
    }
    } catch(BookException e) {
    	logger.error("Book Controller : " + e.getMessage());
    	e.printStackTrace();
    	return new ResponseEntity<Book>(HttpStatus.EXPECTATION_FAILED);
    }
  }
}