package com.cg.lms.controller;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.lms.dto.*;
import com.cg.lms.exception.IssuedException;
import com.cg.lms.service.*;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class IssuedController {
	@Autowired
	IssuedService issuedService;
	@Autowired
	BookService bookService;
	@Autowired
	StudentService studentService;
	
	Logger logger = LoggerFactory.getLogger(BookController.class);	
	
	
	@PostMapping(value = "/issued/request")
	public ResponseEntity<Issued> register(@RequestParam("stuId") long stuId, @RequestParam("bookId") long bookId) {
		try {
			Student student = studentService.getStudentById(stuId);
			Book book = bookService.getBookById(bookId);
			Issued issued = new Issued(student,book,LocalDateTime.now(),LocalDateTime.now(),false,false);
			issued.setIssuedId(1);
			Issued _issued = issuedService.requestBook(issued);
			System.out.println(_issued);
			logger.info("Issued Controller : " + _issued);
			return new ResponseEntity<>(_issued, HttpStatus.CREATED);
	    } catch (IssuedException e) {
	    	logger.error("Issued Controller : " + e.getMessage());
	    	return new ResponseEntity<Issued>(HttpStatus.EXPECTATION_FAILED);
	    }
	}
	
	@GetMapping(value = "/issued/approve/{id}")
	public ResponseEntity<Issued> approveBook(@PathVariable("id") long id) {
	    Issued _issued = issuedService.approveBook(id);
	    if (_issued!=null) {
		  logger.info("Issued Controller : " + _issued);
	      return new ResponseEntity<>(_issued, HttpStatus.OK);
	    } else {
		  logger.info("Issued Controller : Issued Record Not Found");
	      return new ResponseEntity<Issued>(HttpStatus.NOT_FOUND);
	    }
	}
	
	@GetMapping(value = "/issued/return/{id}")
	public ResponseEntity<Issued> returnBook(@PathVariable("id") long id) {
	    Issued _issued = issuedService.returnBook(id);	    
	    if (_issued!=null) {
	      logger.info("Issued Controller : " + _issued);
	      return new ResponseEntity<>(_issued, HttpStatus.OK);
	    } else {
	      logger.info("Issued Controller : Issued Record Not Found");
	      return new ResponseEntity<Issued>(HttpStatus.NOT_FOUND);
	    }
	}	
	
}
