package com.cg.lms.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.lms.dto.Login;
import com.cg.lms.dto.Student;
import com.cg.lms.exception.StudentException;
import com.cg.lms.service.StudentService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class StudentController {	 

	  Logger logger = LoggerFactory.getLogger(BookController.class);	

	
	  @Autowired
	  StudentService studentService;
	 
	  @GetMapping("/students")
	  public ResponseEntity<List<Student>> getAllStudents() {
	    try {
		    List<Student> students = studentService.getAllStudents();
		    System.out.println(students);
	      if (students.isEmpty()) {
	    	logger.info("Student Controller : Students List is Empty");
	        return new ResponseEntity<List<Student>>(HttpStatus.NO_CONTENT);
	      }
	      logger.info("Student Controller : " + students);
	      return new ResponseEntity<List<Student>>(students, HttpStatus.OK);
	    } catch (StudentException e) {
		  logger.error("Student Controller : " + e);
	      return new ResponseEntity<List<Student>>(HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }
	  
	  @GetMapping("/students/{id}")
	  public ResponseEntity<Student> getStudentById(@PathVariable("id") long id) {
	    Student student = studentService.getStudentById(id);
	    System.out.println(student);
	    if (student!=null) {
		  logger.info("Student Controller : " + student);
	      return new ResponseEntity<>(student, HttpStatus.OK);
	    } else {
		  logger.info("Student Controller : Student Not Found");
	      return new ResponseEntity<Student>(HttpStatus.NOT_FOUND);
	    }
	  }
	 
	  
	  @PostMapping(value = "/students/register")
	  public ResponseEntity<Student> register(@RequestBody Student student) {
	    try {
	    	student.setStuId(1);
	      Student _student = studentService.register(student);
	      logger.info("Student Controller : " + _student);
	      return new ResponseEntity<>(_student, HttpStatus.CREATED);
	    } catch (StudentException e) {
	      logger.error("Student Controller : " + e);
	      return new ResponseEntity<Student>(HttpStatus.EXPECTATION_FAILED);
	    }
	  }

	  
	  @PostMapping(value = "/students/login")
	  public ResponseEntity<Student> login(@RequestBody Login login) {
	    try {
	      Student student = studentService.login(login);
	 
	      if (student==null) {
		      logger.info("Student Controller : Login Failed");
	    	  return new ResponseEntity<Student>(HttpStatus.NO_CONTENT);
	      }
	      logger.info("Student Controller : " + student);
	      return new ResponseEntity<Student>(student, HttpStatus.OK);
	    } catch (StudentException e) {
			logger.error("Student Controller : " + e);
	    	return new ResponseEntity<Student>(HttpStatus.EXPECTATION_FAILED);
	    }
	  }
	  
	  
	  @DeleteMapping("/students/{id}")
	  public ResponseEntity<HttpStatus> deleteStudent(@PathVariable("id") long id) {
	    try {
	    	studentService.deleteStudent(id);
		  logger.info("Student Controller : Student Record Deleted Successfully");
	      return new ResponseEntity<HttpStatus>(HttpStatus.NO_CONTENT);
	    } catch (StudentException e) {
	      logger.error("Student Controller : " + e);
	      return new ResponseEntity<HttpStatus>(HttpStatus.EXPECTATION_FAILED);
	    }
	  }
	 
	  @DeleteMapping("/students")
	  public ResponseEntity<HttpStatus> deleteAllStudents() {
	    try {
	      studentService.deleteAllStudents();
	      logger.info("Student Controller : Student Records Deleted Successfully");
	      return new ResponseEntity<HttpStatus>(HttpStatus.NO_CONTENT);
	    } catch (StudentException e) {
	      logger.info("Student Controller : " + e);	    	
	      return new ResponseEntity<HttpStatus>(HttpStatus.EXPECTATION_FAILED);
	    }
	 
	  }
	 
	 
	  @PutMapping("/students/{id}")
	  public ResponseEntity<Student> updateStudent(@PathVariable("id") long id, @RequestBody Student student) {
	    Student _student = studentService.updateStudent(id, student);
	 
	    if (_student!=null) {
		  logger.info("Student Controller : " + _student);
	      return new ResponseEntity<>(_student, HttpStatus.OK);
	    } else {
		  logger.info("Student Controller : Student Record Not Found");
	      return new ResponseEntity<Student>(HttpStatus.NOT_FOUND);
	    }
	  }
}	
	
