package com.cg.lms.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "book")
public class Book implements Serializable {
	private static final long serialVersionUID = -3946091634178111941L;
		
	@Id
	@Column(name = "book_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long bookId;
 
	@Column(name = "book_name")
	private String bookName;
 
	@Column(name = "book_author")
	private String bookAuthor;
 
	@Column(name = "book_cover")
	private String bookCover;
  
	@Column(name = "book_pages")
	private int bookPages;
  
	@Column(name = "book_stock")
	private int bookStock;
 
	@JsonManagedReference(value="books")
	@OneToMany(mappedBy = "book",cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<Issued> issuedBooks;
   
	public Book()
	{		
	}
	
	
	{
		this.issuedBooks=new ArrayList<Issued>(0);
	}
	
	public Book(String bookName, String bookAuthor, String bookCover, int bookPages, int bookStock,
			List<Issued> issuedBooks) {
		super();
		this.bookName = bookName;
		this.bookAuthor = bookAuthor;
		this.bookCover = bookCover;
		this.bookPages = bookPages;
		this.bookStock = bookStock;
		this.issuedBooks = issuedBooks;
	}
	
	public long getBookId() {
		return bookId;
	}

	public void setBookId(long bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}


	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public String getBookCover() {
		return bookCover;
	}

	public void setBookCover(String bookCover) {
		this.bookCover = bookCover;
	}

	public int getBookPages() {
		return bookPages;
	}

	public void setBookPages(int bookPages) {
		this.bookPages = bookPages;
	}

	public int getBookStock() {
		return bookStock;
	}

	public void setBookStock(int bookStock) {
		this.bookStock = bookStock;
	}

	public List<Issued> getIssuedBooks() {
		return issuedBooks;
	}

	public void setIssuedBooks(List<Issued> issuedBooks) {
		this.issuedBooks = issuedBooks;
	}	
	
	@Override
	public String toString() {
		return "Book [id=" + bookId + ", name=" + bookName + ", author=" + bookAuthor + ", cover=" + bookCover +  ", pages=" + bookPages +  ", stock=" + bookStock +"]";
	}
	
	@Override
	public int hashCode() {		
		return this.bookId.intValue();
	}

	@Override
	public boolean equals(Object obj) {
		boolean status= false;
		if(obj!=null)
			status= this.hashCode()==obj.hashCode();
		return status;
	}	
}