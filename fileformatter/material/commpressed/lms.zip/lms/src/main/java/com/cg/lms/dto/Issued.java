package com.cg.lms.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "issued")
public class Issued implements Serializable {
	private static final long serialVersionUID = -3946091644448333943L;
	
	@Id
	@Column(name = "issued_id")
	@GeneratedValue(strategy = GenerationType.AUTO)	
	private Long issuedId;
	
	@JsonBackReference(value="students")
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER )
	@JoinColumn(name = "stu_id")	
	private Student student;

	@JsonBackReference(value="books")
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER )
	@JoinColumn(name = "book_id")	
	private Book book;

	@Column(name = "issued_date")
	private LocalDateTime issuedDate;

	@Column(name = "returned_date")
	private LocalDateTime returnedDate;
	
	@Column(name = "is_issued")
	private boolean isIssued;

	@Column(name = "is_returned")
	private boolean isReturned;

	public Issued() {
		
	}
	
	public Issued(Student student, Book book, LocalDateTime issuedDate, LocalDateTime returnedDate, boolean isIssued,
			boolean isReturned) {
		super();
		this.student = student;
		this.book = book;
		this.issuedDate = issuedDate;
		this.returnedDate = returnedDate;
		this.isIssued = isIssued;
		this.isReturned = isReturned;
	}

	public long getIssuedId() {
		return issuedId;
	}

	public void setIssuedId(long issuedId) {
		this.issuedId = issuedId;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	@JsonProperty
	public Long getStudentId() {
	    return student == null ? null : student.getStuId();
	}

	@JsonProperty
	public Long getBookId() {
	    return book == null ? null : book.getBookId();
	}
	
	
	public LocalDateTime getIssuedDate() {
		return issuedDate;
	}

	public void setIssuedDate(LocalDateTime issuedDate) {
		this.issuedDate = issuedDate;
	}

	public LocalDateTime getReturnedDate() {
		return returnedDate;
	}

	public void setReturnedDate(LocalDateTime returnedDate) {
		this.returnedDate = returnedDate;
	}

	public boolean isIssued() {
		return isIssued;
	}

	public void setIssued(boolean isIssued) {
		this.isIssued = isIssued;
	}

	public boolean isReturned() {
		return isReturned;
	}

	public void setReturned(boolean isReturned) {
		this.isReturned = isReturned;
	}
	
	
	@Override
	public String toString() {
		return "Issued [IssuedId=" + issuedId + ", Student=" + student + ", Book=" + book
				+ ", IssuedDate=" + issuedDate + ", returnedDate=" + returnedDate + ", IsIssued=" + isIssued + ", IsReturned=" + isReturned + "]";
	}
	
	@Override
	public int hashCode() {		
		return this.issuedId.intValue();
	}

	@Override
	public boolean equals(Object obj) {
		boolean status= false;
		if(obj!=null)
			status= this.hashCode()==obj.hashCode();
		return status;
	}
}
