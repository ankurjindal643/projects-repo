package com.cg.lms.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.CascadeType;


@Entity
@Table(name = "student")
public class Student implements Serializable {
	private static final long serialVersionUID = -3946091644448333942L;

	
	@Id
	@Column(name = "stu_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long stuId;
	
	@Column(name = "stu_name")
	private String stuName;
	
	@Column(name = "stu_password")
	private String stuPassword;
	 
	@Column(name = "stu_contact")
	private String stuContact;
	  
	@Column(name = "stu_email")
	private String stuEmail;
	  
	@Column(name = "stu_gender")
	private String stuGender;	
	
	@JsonManagedReference(value="students")
	@OneToMany(mappedBy = "student",cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<Issued> issuedBooks;
	
	public Student()
	{
		this.issuedBooks=new ArrayList<Issued>(0);
	}
	
	public Student(String stuName, String stuPassword, String stuContact, String stuEmail, String stuGender,
			List<Issued> issuedBooks) {
		super();
		this.stuName = stuName;
		this.stuPassword = stuPassword;
		this.stuContact = stuContact;
		this.stuEmail = stuEmail;
		this.stuGender = stuGender;
		this.issuedBooks = issuedBooks;
	}

	public long getStuId() {
		return stuId;
	}

	public void setStuId(long stuId) {
		this.stuId = stuId;
	}

	public String getStuName() {
		return stuName;
	}
	
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	
	public String getStuPassword() {
		return stuPassword;
	}
	
	public void setStuPassword(String stuPassword) {
		this.stuPassword = stuPassword;
	}
	
	public String getStuContact() {
		return stuContact;
	}
	
	public void setStuContact(String stuContact) {
		this.stuContact = stuContact;
	}
	
	public String getStuEmail() {
		return stuEmail;
	}
	
	public void setStuEmail(String stuEmail) {
		this.stuEmail = stuEmail;
	}
	
	public String getStuGender() {
		return stuGender;
	}
	
	public void setStuGender(String stuGender) {
		this.stuGender = stuGender;
	}
	
	public List<Issued> getIssuedBooks() {
		return issuedBooks;
	}
	
	public void setIssuedBooks(List<Issued> issuedBooks) {
		this.issuedBooks = issuedBooks;
	}
	  
	  
	@Override
	public String toString() {
		return "Student [StudentId=" + stuId + ", StudentName=" + stuName + ", StudentContact=" + stuContact
				+ ", StudentEmail=" + stuEmail + ", StudentGender=" + stuGender + "]";
	}
	
	@Override
	public int hashCode() {		
		return this.stuId.intValue();
	}

	@Override
	public boolean equals(Object obj) {
		boolean status= false;
		if(obj!=null)
			status= this.hashCode()==obj.hashCode();
		return status;
	}
}
