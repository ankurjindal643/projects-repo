package com.cg.lms.exception;

public class BookException extends RuntimeException {
	private static final long serialVersionUID = -7900677380899033365L;
	
	public BookException() {
	}
	
	public BookException(String message) {
		super(message);
	}
}
