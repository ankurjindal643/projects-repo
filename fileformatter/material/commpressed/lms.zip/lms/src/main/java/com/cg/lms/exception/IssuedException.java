package com.cg.lms.exception;

public class IssuedException extends RuntimeException {
	private static final long serialVersionUID = -7900677380899033390L;
	public IssuedException() {
	}

	public IssuedException(String message) {
		super(message);
	}
}
