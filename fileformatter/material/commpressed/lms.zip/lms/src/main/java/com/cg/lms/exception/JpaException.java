package com.cg.lms.exception;

public class JpaException extends RuntimeException {
	private static final long serialVersionUID = -7900677380899033532L;
	
	public JpaException() {
	}
	
	public JpaException(String message) {
		super(message);
	}
}
