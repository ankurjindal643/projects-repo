package com.cg.lms.exception;

public class StudentException extends RuntimeException {
	private static final long serialVersionUID = -6304469802731292634L;
	
	public StudentException() {
	}
	
	public StudentException(String message) {
		super(message);
	}
}
