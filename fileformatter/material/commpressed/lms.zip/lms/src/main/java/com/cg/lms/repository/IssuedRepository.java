package com.cg.lms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.lms.dto.Issued;

public interface IssuedRepository extends JpaRepository<Issued, Long> {
}
