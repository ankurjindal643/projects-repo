package com.cg.lms.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.lms.dto.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {
	public Optional<Student> findByStuIdAndStuPassword(long stuId, String stuPassword);
}