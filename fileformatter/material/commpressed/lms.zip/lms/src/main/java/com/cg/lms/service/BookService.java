package com.cg.lms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.cg.lms.dto.Book;
import com.cg.lms.repository.BookRepository;


@Service
public class BookService implements IBookService {

	@Autowired
	private BookRepository bookRepository;
	
	@Override
	public Book addBook(Book book) {
		return bookRepository.save(book);
	}

	@Override
	public void deleteBook(long id) {
		bookRepository.deleteById(id);		
	}

	@Override
	public void deleteAllBooks() {
	    bookRepository.deleteAll();
	}

	@Override
	public Book updateBook(long id, Book book) {
		Optional<Book> bookData = bookRepository.findById(id);
	  
	    if (bookData.isPresent()) {
	    	book.setBookId(id);
	      return bookRepository.save(book);
	    } else {
	      return null;
	    }		
	}

	@Override
	public Book getBookById(long id) {
	    Optional<Book> bookData = bookRepository.findById(id);
	    
	    if (bookData.isPresent()) {
	      return bookData.get();
	    } else {
	      return null;
	    }
	}

	@Override
	public List<Book> getAllBooks() {
		List<Book> books = new ArrayList<Book>();
		bookRepository.findAll().forEach(books::add);
		
		if (books.isEmpty()) {
	        return null;
		}
		return books;
	}

	@Override
	public List<Book> getAllBooksByAuthor(String author) {
		List<Book> books = new ArrayList<Book>();
		bookRepository.findByBookAuthor(author).forEach(books::add);
		
		if (books.isEmpty()) {
	        return null;
		}
		return books;
	}
}
