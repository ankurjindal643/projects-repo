package com.cg.lms.service;

import java.util.List;

import com.cg.lms.dto.Book;

public interface IBookService {
	public Book addBook(Book book);
	public void deleteBook(long id);
	public void deleteAllBooks();
	public Book updateBook(long id, Book book);
	public Book getBookById(long id);
	public List<Book> getAllBooks();
	public List<Book> getAllBooksByAuthor(String author);
}
