package com.cg.lms.service;


import com.cg.lms.dto.*;

public interface IIssuedService {
	public Issued requestBook(Issued issued);
	public Issued approveBook(long issuedId);
	public Issued returnBook(long issuedId);
}
