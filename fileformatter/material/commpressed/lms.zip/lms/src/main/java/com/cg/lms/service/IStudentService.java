package com.cg.lms.service;

import java.util.List;

import com.cg.lms.dto.Login;
import com.cg.lms.dto.Student;

public interface IStudentService {
	public Student register(Student student);
	public Student login(Login login);
	public void deleteStudent(long id);
	public void deleteAllStudents();
	public Student updateStudent(long id, Student student);
	public Student getStudentById(long id);
	public List<Student> getAllStudents();
}
