package com.cg.lms.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.lms.dto.Issued;
import com.cg.lms.repository.IssuedRepository;

@Service
public class IssuedService implements IIssuedService {

	@Autowired 
	IssuedRepository issuedRepository;
	
	
	@Override
	public Issued requestBook(Issued issued) {
		return issuedRepository.save(issued);
	}


	@Override
	public Issued approveBook(long issuedId) {
		Optional<Issued> issuedData = issuedRepository.findById(issuedId);
		  
	    if (issuedData.isPresent()) {
	    	Issued _issued = issuedData.get();
	    	_issued.setIssued(true);
	    	_issued.setIssuedDate(LocalDateTime.now());
	    	return issuedRepository.save(_issued);
	    } else {
	      return null;
	    }		
	}


	public Issued returnBook(long issuedId) {
		Optional<Issued> issuedData = issuedRepository.findById(issuedId);
		  
	    if (issuedData.isPresent()) {
	    	Issued _issued = issuedData.get();
	    	_issued.setReturned(true);
	    	_issued.setReturnedDate(LocalDateTime.now());
	    	return issuedRepository.save(_issued);
	    } else {
	      return null;
	    }		
	}
}
