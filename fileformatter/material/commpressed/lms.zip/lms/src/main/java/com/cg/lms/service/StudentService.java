package com.cg.lms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.cg.lms.dto.Login;
import com.cg.lms.dto.Student;
import com.cg.lms.repository.StudentRepository;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class StudentService implements IStudentService {

	@Autowired 
	StudentRepository studentRepository;
	
	@Override
	public Student register(Student student) {
	      return studentRepository.save(student);
	}

	@Override
	public Student login(Login login) {
	      return studentRepository.findByStuIdAndStuPassword(login.getId(),login.getPassword()).get();
	}

	@Override
	public void deleteStudent(long id) {
	      studentRepository.deleteById(id);
	}

	@Override
	public void deleteAllStudents() {
	      studentRepository.deleteAll();
	}

	@Override
	public Student updateStudent(long id, Student student) {
	    Optional<Student> studentData = studentRepository.findById(id);
		 
	    if (studentData.isPresent()) {
	    	student.setStuId(id);
	      return studentRepository.save(student);
	    } else {
	      return null;
	    }
	}

	@Override
	public Student getStudentById(long id) {
	    Optional<Student> studentData = studentRepository.findById(id);
		 
	    if (studentData.isPresent()) {
	      return studentData.get();
	    } else {
	      return null;
	    }
	}

	@Override
	public List<Student> getAllStudents() {
	    List<Student> students = new ArrayList<Student>();
	    studentRepository.findAll().forEach(students::add);
	    return students;
	}

}
